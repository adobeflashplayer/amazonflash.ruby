This directory contains utilities for working with llbuild in
emacs. 

* llbuild-project-settings.el

  Common settings for the llbuild project, including a C style for following the
  llbuild coding conventions.

  This will be automatically loaded via the emacs .dir-locals.el mechanism.
