# llbuild Framework

This directory contains helper files for building an llbuild framework.

The target itself is built by the `libllbuild` product (in CMake).
