This directory contains the public C API headers, they are kept in a separate
directory to allow them to be easily added to compiler search paths and
installed.
