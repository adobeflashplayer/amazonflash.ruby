This directory defines llbuild support for Ninja build manifests.
