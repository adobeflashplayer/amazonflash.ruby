BuildSystem C-API Example
=========================

This is a basic example of using the libllbuild C APIs for working with the
BuildSystem component of llbuild.
